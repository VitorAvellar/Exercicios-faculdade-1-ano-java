
public class Exemplo1 {
	public static void main(String[] args) {
		
		int cont = 1;
		
		for( ; cont <= 10; ) {
			System.out.println(cont);
			cont++;
		}

	}
}
