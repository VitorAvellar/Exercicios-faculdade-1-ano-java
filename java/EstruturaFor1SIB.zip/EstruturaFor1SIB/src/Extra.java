import java.util.Scanner;

public class Extra {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		double y = 0;
		int n;
		double x;
		int fat = 1;
		
		System.out.print("Informe o valor de n inteiro e positivo --> ");
		n = teclado.nextInt();
		System.out.print("Informe o valor de x --> ");
		x = teclado.nextDouble();
		
		for(int cont = 1; cont <= n; cont++) {
			fat = fat * cont;
			y = y + Math.pow(x, cont) / fat;
		}
		System.out.println("y = " + y);
	}
}
