import java.util.Scanner;

public class Exercicio13 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int n, cont;
		double y = 0;

		System.out.print("Informe o valor de n --> ");
		n = teclado.nextInt();
		
		for(cont = 1; cont <= n; cont++) {
			y = y + (double)cont / (n - cont + 1);
		}
		System.out.println("y = " + y);
	}
}
