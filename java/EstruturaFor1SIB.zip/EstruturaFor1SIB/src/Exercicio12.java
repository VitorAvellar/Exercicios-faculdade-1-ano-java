import java.util.Scanner;

public class Exercicio12 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int totalProduto;
		double preco, totalCompra = 0;
		int resposta;
		
		System.out.print("Total de produtos --> ");
		totalProduto = teclado.nextInt();
		
		for(int cont = 1; cont <= totalProduto; cont++) {
			System.out.print("Preço R$ ");
			preco = teclado.nextDouble();
			totalCompra = totalCompra + preco;
		}
		
		System.out.println("Total da compra R$ " + String.format("%.2f", totalCompra));
		System.out.print("1. Pagamento à vista ou 2 Pagmento em duas vezes ");
		resposta = teclado.nextInt();
		if(resposta == 1) {
			totalCompra = totalCompra * 0.9;
			System.out.println("Total para pagamento à vista R$ " + String.format("%.2f", totalCompra));
		} else {
			totalCompra = totalCompra * 1.155;
			System.out.println("Total para pagamento em duas vezes R$ " + String.format("%.2f", totalCompra));
		}
	}
}
