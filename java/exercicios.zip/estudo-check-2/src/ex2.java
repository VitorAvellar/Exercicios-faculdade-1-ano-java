import java.util.Random;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Random gerador = new Random();
		int x[] = new int[gerador.nextInt(10, 20)];
		boolean verific;

		for (int i = 0; i < x.length; i++) {

			x[i] = gerador.nextInt(x.length);

			verific = false;

			for (int v = 0; v < i; v++) {
				if (x[i] == x[v]) {
					verific = true;

				}

			}

			if (verific == false) {
				System.out.println("O valor do indice " + i + " �: " + x[i]);
				i++;
			}

		}

	}

}
