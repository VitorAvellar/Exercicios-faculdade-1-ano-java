import java.util.Random;

public class exemplorandon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Random gerador = new Random();
		int[] x = new int[5];
		boolean verific;

		for (int i = 0; i < x.length; i++) {
			x[i] = gerador.nextInt(1, 10);
			verific = false;

			for (int v = 0; v < x.length; v++) {
				if (x[i] == x[v] - 1) {
					verific = true;

				}

			}

		}

	}

}
