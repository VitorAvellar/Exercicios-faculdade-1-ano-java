import java.util.Random;
import java.util.Scanner;

public class ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Random gerador = new Random();
		Scanner teclado = new Scanner(System.in);
		int[] x = new int[gerador.nextInt(2, 15)];
		int aux;

		System.out.println("Antes da ordem: ");
		for (int i = 0; i < x.length; i++) {
			x[i] = gerador.nextInt(15, 156);
				System.out.print(x[i] + " ");
		}

		for (int v = 1; v <= x.length; v++) {
			for (int i = 0; i < x.length - 1; i++) {
				if (x[i] > x[i + 1]) {
					aux = x[i + 1];
					x[i + 1] = x[i];
					x[i] = aux;

				}

			}
		}
		System.out.println("Em ordem crescente o valor �:" );
		for(int i = 0; i < x.length; i++) {
			System.out.print(x[i] + " ");
		}
			

	}

}
