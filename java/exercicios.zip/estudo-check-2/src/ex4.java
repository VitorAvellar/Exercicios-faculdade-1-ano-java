import java.util.Scanner;

public class ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado = new Scanner(System.in);
		int x [] = new int[5]; 
	   int par = 0;
	   
	   
	   for(int i = 0; i < x.length; i++) {
		   System.out.println("digite o valor do vetor: ");
		   x[i] = teclado.nextInt();
		   
		  
		   
		   if(x[i] % 2 == 0) {
			   par++;
			 
			   
		   }
		   
	   }
	   
	   System.out.println("O total de pares �: " + par);
	   System.out.println("O total de impares �: " + ( x.length - par));
	   
	   
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
