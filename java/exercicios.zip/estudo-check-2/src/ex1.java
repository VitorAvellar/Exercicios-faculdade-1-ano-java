import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		 int[] numero = new int[5];
		 int maior = Integer.MAX_VALUE;
		 int menor = Integer.MIN_VALUE;
		 Scanner teclado = new Scanner(System.in);
		 
		 for(int i = 0; i < numero.length; i++ ) {
			 
			 System.out.println("digite o valor dos indices: ");
			 numero[i] = teclado.nextInt();
			 
			 if(numero[i] < maior) {
				 maior = numero[i];
			 }
		
			if(numero[i] > menor) {
				menor = numero[i];
			}
			  
		 }
		 
		System.out.println("Menor: " + maior);
		System.out.println("Maior: " + menor);
		
		
		
		
		
		
	}

}
