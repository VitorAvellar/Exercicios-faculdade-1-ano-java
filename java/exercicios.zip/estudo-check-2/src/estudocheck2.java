import java.util.Scanner;

public class estudocheck2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		Scanner teclado = new Scanner(System.in);
		int numsalas;
		int numalunos, sala;
		int[] nota;
		double media, porcentagem;
		
		
		System.out.println("informe o numero de salas: ");
		numsalas = teclado.nextInt();

		for (sala = 1; sala <= numsalas; sala++) {
			System.out.println("sala: #" + sala);

			System.out.print("Informe o numero de alunos: ");
			numalunos = teclado.nextInt();

			nota = new int[numalunos];
			
			media = 0;
					
			for (int aluno = 0; aluno < numalunos; aluno++) {

				System.out.print("nota do aluno: #" + (aluno + 1) + " ");
				nota[aluno] = teclado.nextInt();
				 
				media = media + nota[aluno];
				
				
			}

			media = media / numalunos;
			System.out.println("media final:" + String.format("%.3f", media));
			
			porcentagem = 0;
			
			for(int i = 0; i < nota.length; i++) {
				if(nota [i]  > media) {
					porcentagem++;
					
				}
			}
				porcentagem = porcentagem / numalunos * 100;
				System.out.println("Porcentagem de alunos acima da media " + String.format("%.3f", porcentagem) + "%");
			
			System.out.println();
			
		}

	}

}
