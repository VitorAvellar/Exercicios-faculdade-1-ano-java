import java.util.Scanner;

public class Exercicioprova2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double m,c,i, n;
		Scanner teclado = new Scanner(System.in);
		
		
		System.out.print("coloque o capital para investir:$");
		c = teclado.nextDouble();
		
		System.out.print("Coloque a quantidade de meses: ");
		n = teclado.nextDouble();
		
		System.out.print("coloque os juros:% ");
		i = teclado.nextDouble();
		
		m = c * Math.pow(1 + i, n);
		
		System.out.print("o montante � de:$ " + m );
		
		
		
		
		
		
		
		
		
		
	}

}
