package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double p1,p2,t1,t2,t3,mp,mt,mf;
	    Scanner teclado = new Scanner(System.in);
	    
	    
		
		System.out.println("Coloque a nota da prova 1: ");
		p1 = teclado.nextDouble();
		
		System.out.println("Coloque a nota da prova 2: ");
		p2 = teclado.nextDouble();
		
		System.out.println("Coloque a nota do trabalho 1: ");
		t1 = teclado.nextDouble();
		
		System.out.println("Coloque a nota do trabalho 2: ");
		t2 = teclado.nextDouble();
		
		System.out.println("Coloque a nota do trabalho 3: ");
		t3 = teclado.nextDouble();
		
		
		mp = ((p1 + p2) / 2) * 0.7;
		mt = ((t1 + t2 + t3) / 3) * 0.3;
		
		
		mf = mp + mt;
		
		
		System.out.println("A media final foi de: " + mf);
		
		if(mf < 6) {
			System.out.println("o aluno foi REPROVADO" );
		}
		
		else {
			System.out.println("o aluno foi APROVADO");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
