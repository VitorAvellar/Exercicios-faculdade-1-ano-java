package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double valorp, porcentagemd, valordescontado;
		Scanner teclado = new Scanner(System.in);
		
       System.out.print("Digite o valor do produto em reais: $");
       valorp = teclado.nextDouble();
       
       System.out.print("Digite o desconto em: %");
	   porcentagemd = teclado.nextDouble();
	   
	   valordescontado = porcentagemd / 100 * valorp;
	   
	   System.out.println("o valor final �: $" + valordescontado);
		
		
		
		
		
		
	}

}
