package globalsolutionexercicio;

import java.util.Scanner;

public class exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double c, f ;
	    Scanner teclado = new Scanner(System.in);
	    
	    System.out.println("coloque a temperatura em celsius: ");
	    c = teclado.nextDouble();
	    
	    f = c * 1.8 + 32;
	    
	    
	    System.out.println("A temperatura em farenheit �:" + f);
	    
	    
	
    		
		
		
		
		
		
		
	}

}
