package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		double valortotal,econom,valorfinal;
		Scanner teclado = new Scanner(System.in);
		
		
		System.out.println("informe o valor total das compras:$");
		valortotal = teclado.nextDouble();
		
		if(valortotal > 10000) {
			valorfinal = valortotal * 0.15;
			econom = valortotal - valorfinal;
			System.out.println("o valor com o desconto de 15% fica:$" + valorfinal);
			System.out.println("O valor economizado foi de: " + econom);
		}
		
		if (valortotal <= 10000) {
			valorfinal = valortotal * 0.8;
			econom = valortotal - valorfinal;
			System.out.println("o valor com o desconto de 8% fica:$" + valorfinal);
			System.out.println("O valor economizado foi de: " + econom);
		}
		
		
		
		
		
		
		
		
		
		
		
	}

}
