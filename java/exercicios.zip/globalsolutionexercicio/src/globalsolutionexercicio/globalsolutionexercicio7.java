package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int x;
		double y;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("coloque o valor de X: ");
		x = teclado.nextInt();
		if (x <= 0 ) {
			System.out.println("N�O PODE NUMERO NEGATIVO OU ZERO!");
		}
		else {
			y = 8 / (Math.sqrt(Math.pow(x, 2 )-25));
			System.out.println("O valor de y �: " + y);
		}
		
		
		
		
		
		
		
	}

}
