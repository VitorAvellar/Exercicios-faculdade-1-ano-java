package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		double a, b, c, sp, sp1, area;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("coloque o valor do lado A: ");
		a = teclado.nextDouble();
		
		System.out.println("coloque o valor do lado B: ");
		b = teclado.nextDouble();
		
		System.out.println("coloque o valor do lado C: ");
		c = teclado.nextDouble();
		
		
		
		sp = a + b + c ;
		sp1 = sp/2;
		
		area = Math.sqrt(sp1 * (sp1 - a) * (sp1 - b) * (sp1 - c));
		
		System.out.println("o valor da area �: " + area);
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
