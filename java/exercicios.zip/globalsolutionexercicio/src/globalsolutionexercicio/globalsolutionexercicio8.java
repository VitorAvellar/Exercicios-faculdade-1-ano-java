package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double lado1,lado2,lado3;
		Scanner teclado = new Scanner(System.in);
		
		
		System.out.println("coloque o valor de um dos lados: ");
		lado1 = teclado.nextDouble();
		
		System.out.println("coloque o valor de um dos lados: ");
		lado2 = teclado.nextDouble();

		
		System.out.println("coloque o valor de um dos lados: ");
		lado3 = teclado.nextDouble();

		
		if(lado1 > lado2 + lado3 || lado2 > lado1 + lado3 || lado3 > lado1 + lado2) {
			System.out.println("N�o � um triangulo");	
		}
		
		else {
			System.out.println("TRIANGULO");
		}
		
	}

}
