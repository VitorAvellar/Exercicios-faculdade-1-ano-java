package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int valor,cont,resultado;
		cont = 1;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("digite um valor");
		valor = teclado.nextInt();
		
		while(cont <= 10) {
			resultado = valor * cont;
			System.out.println(valor + " * " + cont + " = " + resultado);
			cont = cont + 1;
		}
		
		
		
		
		
		
		
		
		
		
	}

}
