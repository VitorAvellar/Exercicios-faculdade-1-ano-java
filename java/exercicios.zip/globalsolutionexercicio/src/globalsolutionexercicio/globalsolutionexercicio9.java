package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String gerente, engenheiro, tecnico, cargo;
		int temposerv;
		double aumento, salario, salarionovo;
		Scanner teclado = new Scanner(System.in);

		System.out.println("qual o seu cargo");
		cargo = teclado.next();

		if (cargo.equals("gerente")) {
			System.out.println("o seu cargo � gerente");

			System.out.println("qual o seu tempo de servi�o em anos:");
			temposerv = teclado.nextInt();

			System.out.print("qual seu salario atual: $");
			salario = teclado.nextDouble();
			if (temposerv >= 5) {
               
				aumento = salario * 0.10;
				System.out.println("o aumento do seu salario � de: $" + aumento);
				salarionovo = salario + aumento;
				System.out.print("o total fica $" + salarionovo);

				 if (temposerv >= 3 && temposerv < 5) {
					 
					     aumento = salario * 0.9;
						System.out.println("o aumento do seu salario � de: $" + aumento);
						salarionovo = salario + aumento;
						System.out.print("o total fica $" + salarionovo);
				}
			
			
			
			
			}

		}
		
			
				
		
		
		
		
		
		
	}

}
