package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		int t3, t1,t2;
		Scanner teclado = new Scanner(System.in);
		
		
		
		//System.out.println("informe o a quantidade de pessoas do terceiro ink: ");
		//t3 = teclado.nextInt();
		t3 = 25;
        t2 = t3 * 2;
        t1 = t2 * 2;
        
        System.out.println("A quantidade que clicaram no link 1 �: " + t1);
		
		
		
		
		
		
		
		
	}

}
