package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int n1,n2;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("coloque o valor de n1");
		n1 = teclado.nextInt();
		
		System.out.println("coloque o valor de n2");
		n2 = teclado.nextInt();
		
		if(n2 > n1 && n1 > 0) {
			while(n1 <= n2) {
				System.out.println( n1 );
				n1 = n1 + 1;
			}
		}
		
			
		
		
		
		
				
		
		
		
		
	}

}
