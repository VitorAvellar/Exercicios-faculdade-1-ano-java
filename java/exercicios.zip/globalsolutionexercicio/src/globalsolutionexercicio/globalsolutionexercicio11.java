package globalsolutionexercicio;

import java.util.Scanner;

public class globalsolutionexercicio11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int cont, numero,maior;
		cont = 1;
		maior = 0;
		Scanner teclado = new Scanner(System.in);
		
		
		while (cont <= 5) {
			System.out.println("numero");
			numero = teclado.nextInt();
			
			if(numero > maior || cont == 1) {
				maior = numero;
			}
			cont = cont +1;
		}
		
		System.out.println("maior = " + maior);
		
		
		
		
		
	}

}
