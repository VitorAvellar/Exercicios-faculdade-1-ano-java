import java.util.Scanner;

public class matriz {
	public static void main(String[] args) {

		int[][] x = new int[2][3];
		Scanner teclado = new Scanner(System.in);

		// entrada de dados
		for (int i = 0; i < x.length; i++) { // i controla as linhas da matriz

			for (int j = 0; j < x[i].length; j++) { // j controla as colunas da matriz
				System.out.print("digite um valor: ");
				x[i][j] = teclado.nextInt();

			}

		}

		// impress�o dos dados no formato de uma tabela

		for (int i = 0; i < x.length; i++) { // i controla as linhas da matriz

			for (int j = 0; j < x[i].length; j++) { // j controla as colunas da matriz

				System.out.print(x[i][j] + "\t");

			}
			System.out.println();
		}

	}
}