import java.util.Random;
import java.util.Scanner;

public class exemplo1 {

	public static void main(String[] args) {
			Scanner teclado = new Scanner(System.in);
			int  [][] x = new int [10][10];
			Random gerador =  new Random();
			
			for(int i = 0; i < x.length; i++) {
				for(int j = 0; j < x.length; j++) {
					
					x[i][j] = gerador.nextInt(100);
					System.out.print(x[i][j] + "\t");
				}
				System.out.println();
			}
			
				



	}

}
