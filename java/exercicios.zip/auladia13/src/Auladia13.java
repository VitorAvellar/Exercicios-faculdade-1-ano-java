import java.util.Scanner;

public class Auladia13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double h, r;
		double area, valor, lata;
		Scanner teclado = new Scanner(System.in);

		System.out.println("insira o r: ");
		r = teclado.nextDouble();
		System.out.println("insira o h: ");
		h = teclado.nextDouble();

		area = 2 * Math.PI * r * (h + r);
		lata = area / 3 /5;
		valor = lata * 190;
		
		System.out.println("total de latas: " + lata);
		System.out.println("valor da lata: " + valor);

	}

}
