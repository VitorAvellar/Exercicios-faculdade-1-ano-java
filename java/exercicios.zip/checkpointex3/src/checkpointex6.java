import java.util.Scanner;

public class checkpointex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		double mf, mdp, mdt, resultadoMDT, resultadoMDP;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("coloque media das provas: ");
		mdp = teclado.nextDouble();
		
		
		System.out.println("coloque media dos trabalhos: ");
		mdt = teclado.nextDouble();
		
		
		resultadoMDP = mdp * 0.7;
		resultadoMDT = mdt * 0.3;
		mf = resultadoMDP + resultadoMDT;
		
	if( mf < 6) {
		System.out.println("ALUNO REPROVADO");
		
	}
	else {
		System.out.println("ALUNO APROVADO"+ mf);
	}
		
		
		
		
		
		
		
		
		
		
	}

}
