import java.util.Scanner;

public class checkpointex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int n1, n2, n3, resultado;
	   Scanner teclado = new Scanner(System.in);
	   
	   System.out.println("informe o primeiro numero: ");
	   n1 = teclado.nextInt();
	  
	   System.out.println("informe o segundo numero: ");
	   n2 = teclado.nextInt();
	   
	   System.out.println("informe o terceiro numero: ");
	   n3 = teclado.nextInt();
		
	   
	   if(n1 == n2 && n1 == n3 && n2 == n1 && n2 == n3 && n3 == n1 && n3 == n2) {
		   System.out.println("s�o iguais � isso");   
	   }
	   else if(n1 < n2 && n1 < n3) {
			System.out.println("o menor numero � o " + n1);
		}
	 
	   else if(n2 < n1 && n2 < n3) {
		   System.out.println("o menor numero � o " + n2);
	   }
	    
	   else {
		   System.out.println("o menor numero � o " + n3);
	   }
		
		
		
		
		
		
	}

}
