import java.util.Scanner;

public class checkpointex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double h, peso;
		String nome, masculino, feminino, genero;
		Scanner teclado = new Scanner(System.in);

		System.out.println("insira o seu nome: ");
		nome = teclado.next();

		System.out.println("insira a sua altura em metros: ");
		h = teclado.nextDouble();

		System.out.println("escolha o seu genero");
		genero = teclado.next();

		if (genero.equalsIgnoreCase("masculino")) {
			peso = 72.7 * h - 58;
			System.out.println(" o seu peso ideal � " + peso);
		} else if (genero.equalsIgnoreCase("feminino")) {
			peso = 62.1 * h - 44.7;
			System.out.println(" o seu peso ideal � " + peso);
		}

		else {
			System.out.println("genero n�o indentificado");
		}

	}

}
