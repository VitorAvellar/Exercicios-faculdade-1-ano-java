import java.util.Scanner;

public class checkpointex5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		double x, y;
		Scanner teclado = new Scanner(System.in);
		
		
	   System.out.println("insira o valor de X ");
	   x = teclado.nextDouble();
	   
	   
	   if (x <= 5  ) {
		   System.out.println("NUMERO INVALIDO TENTE ALGO MAIOR QUE 5");
	   }
	   else {
		   y = 8 / Math.sqrt(Math.pow(x, 2) - 25);
		   System.out.println("o resultado �" + y);
	   }
		
		
		
	}

}
