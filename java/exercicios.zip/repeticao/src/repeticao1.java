mport java.util.Scanner;

public class repeticao1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int n1 ; 
		double resultado = 1;
		int cont = 1;
		Scanner teclado = new Scanner(System.in);
		
		
	 
		do {
			System.out.print("coloque o numero inteiro e positivo: ");
			n1 = teclado.nextInt();
			if(n1 < 0) {
				System.out.println("valor invalido");
			}
		}
		while (n1 < 0);
			
		while(cont <= n1) {
			resultado = resultado * cont;
			cont++;
		}
		System.out.println(resultado);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
