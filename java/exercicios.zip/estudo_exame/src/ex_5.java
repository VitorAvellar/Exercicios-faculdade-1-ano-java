import java.util.Scanner;

public class ex_5 {

	public static void main(String[] args) {

	Scanner teclado = new Scanner(System.in);
	
	int valor;
	
	System.out.println("Digite um valor: ");
	valor = teclado.nextInt();
	
		divisor(valor);
		
	}
	
	public static void divisor(int valor) {
		
		for (int i = valor; i > 0; i--) {
			
			if(valor % i == 0) {
				System.out.println(i);
				
			}
			
		}
		
	}

}
