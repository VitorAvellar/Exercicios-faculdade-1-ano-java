import java.util.Random;

public class ex_8 {

	public static void main(String[] args) {

	
		
		int vetor[] = new int [11];
		
		gerador(vetor);
		impressao(vetor);
		System.out.println("-----------");
		inverso(vetor);
		
		
	}

	public static void gerador (int vetor [] ) {
		
		Random gerador =  new Random();
		
		for (int i = 0; i < vetor.length; i++) {
			
			vetor[i] = gerador.nextInt(20);
		}
	}
	
	public static void impressao (int vetor[]) {
		
		for (int i = 0; i < vetor.length; i++) {
			
			System.out.println(vetor[i]);
		}
		
	}
	
	public static void inverso (int vetor[]) {
		
		for (int i = 1; vetor[i] > 0 ; i++) {
			
			i *=10;
			i += (vetor[i % 10]);
			
			vetor[i] /= 10;
			
		System.out.println(vetor[i]);	
		}
	}
	
	
	
}
