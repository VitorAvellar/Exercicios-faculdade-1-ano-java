import java.util.Scanner;

public class ex_6 {

	public static void main(String[] args) {
		
		
		Scanner tecaldo =  new Scanner(System.in);
		
		int v1,v2,v3;
		
		System.out.println("Digite o valor 1: " );
		v1 = tecaldo.nextInt();
		
		System.out.println("Digite o valor 2: " );
		v2 = tecaldo.nextInt();
		
		System.out.println("Digite o valor 3: " );
		v3 = tecaldo.nextInt();
		
		
		
		testeTriangulo(v1, v2, v3);
		

	}
	
	public static void testeTriangulo (int v1, int v2, int v3 ) {
		
		
		if(v1 == v2 && v1 == v3 && v2 == v3){
			
			System.out.println("triangulo equilatero");
			
		}
		
		if(v1 == v2 && v1 != v2 && v1 == v3 && v1 != v3 && v3 == v2 && v3 != v2) {
			System.out.println("triangulo isoceles");
		}
		
		if (v1 != v2 && v1 != v3 & v2 != v3) {
			System.out.println("triangulo escaleno");
		}
	}
	
	

}
