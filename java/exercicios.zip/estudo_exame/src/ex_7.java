import java.util.Scanner;

public class ex_7 {

	public static void main(String[] args) {
		
		Scanner teclado =  new Scanner(System.in);
		
		int n1,n2,n3;
		int maior = -200;
		
		System.out.println("digite um valor: ");
		n1 = teclado.nextInt();
		
		System.out.println("digite um valor: ");
		n2 = teclado.nextInt();
		
		System.out.println("digite um valor: ");
		n3 = teclado.nextInt();
		
		
		//TesteMaior(n1, n2, n3, maior);
		
		maior = TesteMaior(n1, n2, n3, maior);
		System.out.println("numero maior �: " + maior);
		
	}

	public static int TesteMaior(int n1, int n2, int n3, int maior) {
		
		if (n1 > maior) {
			
			maior = n1;
		}
		if(n2 > maior) {
			maior  = n2;
		}
		
		if(n3 > maior) {
			maior = n3;
		}
	return maior;
	}
	
	
	
}
