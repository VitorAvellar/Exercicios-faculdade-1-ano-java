import java.util.Scanner;

public class ex_2 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		int qtdAlunos;

		System.out.println("quantidade de alunos que votar�o: ");
		qtdAlunos = teclado.nextInt();

		int votos[] = new int[qtdAlunos];
		int positivo = 0, negativo = 0;

		for (int i = 0; i < votos.length; i++) {

			System.out.println("Aluno " + (i + 1) + " vote 1 para 'SIM' ou 2 para 'N�O'");
			votos[i] = teclado.nextInt();

			if (votos[i] != 1 && votos[i] != 2) {

				System.out.println("APENAS NUMEROS 1 e 2");
			}

			if (votos[i] == 1) {

				votos[i] = positivo;
				positivo++;

				positivo = (positivo * 100 / qtdAlunos);

			}

			if (votos[i] == 2) {

				votos[i] = negativo;
				negativo++;
				negativo = (negativo * 100 / qtdAlunos);
			}

		}
		System.out.println("positivos " + (positivo) + "%");
		System.out.println("negativos " + (negativo) + "%");

	}

}
