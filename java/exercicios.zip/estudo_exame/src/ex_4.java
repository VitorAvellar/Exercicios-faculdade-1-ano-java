import java.util.Random;

public class ex_4 {

	public static void main(String[] args) {
		
		int vetor [] = new int [11];
		int inverso [] = new int [2];
		
		preenchimento(vetor);
		System.out.println("-------------");
		inversao(vetor);

	}

	public static void preenchimento(int vetor []) {
		
		Random gerador = new Random();
		
		for (int i = 0; i < vetor.length; i++) {
			
			vetor[i] = gerador.nextInt(10);
			System.out.println(vetor[i]);
			
		}
	}
	
	public static void inversao (int vetor [] ) {
		
		for (int i = 0; i < vetor.length; i++) {
			
			
			vetor[i] = vetor[i+1];
			
			vetor[i + 1] = vetor[i];
			
			

			System.out.println(vetor[i]);
		}
		
		
	}
	
	
}
