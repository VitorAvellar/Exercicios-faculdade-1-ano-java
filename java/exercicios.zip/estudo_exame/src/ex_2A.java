import java.util.Iterator;
import java.util.Scanner;

public class ex_2A {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		int qtdModelo;

		System.out.println("Quantidade de modelos: ");
		qtdModelo = teclado.nextInt();

		int qtdModelos[] = new int[qtdModelo];
		double valorModelo[] = new double[qtdModelo];
		double valorTotal[] = new double[qtdModelo];
		double finalValor = 0;

		modelos(qtdModelos);
		System.out.println("--------------------------");
		valorModelos(valorModelo, qtdModelos);
		System.out.println("--------------------------");
		totalValor(valorModelo, qtdModelos, valorTotal);
		System.out.println("--------------------------");
		ValorFinal(valorTotal, finalValor);

	}

	public static void modelos(int qtdModelos[]) {

		Scanner teclado = new Scanner(System.in);

		for (int i = 0; i < qtdModelos.length; i++) {
			System.out.print("Quantidade do modelo " + (i + 1) + ": ");
			qtdModelos[i] = teclado.nextInt();

		}

	}

	public static void valorModelos(double valorModelo[], int qtdModelos[]) {
		Scanner teclado = new Scanner(System.in);

		for (int i = 0; i < qtdModelos.length; i++) {

			System.out.print("Valor unitario do modelo " + (i + 1) + ": $");
			valorModelo[i] = teclado.nextDouble();

		}

	}

	public static void totalValor(double valorModelo[], int qtdModelos[], double valorTotal[]) {

		for (int i = 0; i < qtdModelos.length; i++) {

			valorTotal[i] = valorModelo[i] * qtdModelos[i];
			System.out.println("O total do modelo " + (i + 1) + ": $" + valorTotal[i]);

		}

	}

	public static void ValorFinal(double valorTotal[], double finalValor) {

		for (int i = 0; i < valorTotal.length; i++) {

			finalValor += valorTotal[i];

		}
		System.out.println("O valor final � de: " + " $" + (finalValor));

	}

}
