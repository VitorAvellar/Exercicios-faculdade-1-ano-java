import java.util.Scanner;

public class ex_3 {

	public static void main(String[] args) {

		
		Scanner teclado = new Scanner(System.in);
		
		int qtdBikes;
		
		System.out.print("Informe a quantidade de bikes compradas: ");
		qtdBikes = teclado.nextInt();
		
		int modelos [] = new int [qtdBikes];
		double Valores [] = new double [qtdBikes];
		double soma[] = new double [qtdBikes];
		double ValorF = 0;
		
		
		QtdCadaModelo(modelos);
		System.out.println("---------------------");
	    ValorModelo(Valores);
	    System.out.println("---------------------");
	    somaBikes(modelos, Valores, soma);
	    System.out.println("---------------------");
	    ValorT(soma, ValorF);
		
		
	}

	public static void QtdCadaModelo (int modelos []) {
		Scanner teclado = new Scanner(System.in);
		
		for (int i = 0; i < modelos.length; i++) {
			
			System.out.print("Quantidade do modelo " + (i+1) + ": " );
			modelos[i] = teclado.nextInt();
		}
		
		
	}
	
	public static void ValorModelo (double Valor []) {
		Scanner teclado = new Scanner(System.in);
		
		for (int i = 0; i < Valor.length; i++) {
			
			System.out.println("Informe o Valor do modelo " + (i+1) + ": ");
			Valor[i] = teclado.nextInt();
		}
		
	}
	
	public static void somaBikes (int modelos[] , double Valor [] , double somas []) {
		
		
		for (int i = 0; i < somas.length; i++) {
			
			somas[i] = modelos[i] * Valor[i];
			
			System.out.println("A faculdade ira gastar com o modelo " + (i+1) + ": $" + somas[i]);
			
		}
		
	}
	
	public static void ValorT (double somas[] , double ValorF) {
		
		for (int i = 0; i < somas.length; i++) {
			
			ValorF += somas[i];
		}
		System.out.println("Valor final:" + "$" +  ValorF);
		
	}
	
	
}
