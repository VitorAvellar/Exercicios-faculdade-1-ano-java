import java.util.Iterator;
import java.util.Scanner;

public class ex_1 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		int qtdAlugueis;

		System.out.println("digite a quantidade de alugueis");
		qtdAlugueis = teclado.nextInt();

		String nome[] = new String[qtdAlugueis];
		double tempo[] = new double[qtdAlugueis];
		double resultado[] = new double[qtdAlugueis];

		int totais = 0;

		dadosNome(nome);
		System.out.println();
		dadosTempo(tempo, nome);
		System.out.println();
		dadosValor(tempo, nome);
		System.out.println();
		Total(tempo, totais);
		System.out.println();

	}

	public static void dadosNome(String nome[]) {
		Scanner teclado = new Scanner(System.in);

		for (int i = 0; i < nome.length; i++) {

			System.out.println("Nome da pessoa: " + (i + 1));
			nome[i] = teclado.nextLine();

		}
	}

	public static void dadosTempo(double tempo[], String nome[]) {
		Scanner teclado = new Scanner(System.in);

		for (int i = 0; i < tempo.length; i++) {

			System.out.println("tempo(em minutos) que o(a): " + (nome[i]) + "  usou");
			tempo[i] = teclado.nextDouble();
		}

	}

	public static void dadosValor(double tempo[], String nome[]) {
		Scanner teclado = new Scanner(System.in);

		for (int i = 0; i < tempo.length; i++) {

			tempo[i] = tempo[i] * 0.50;

			System.out.println("Total do(a) " + (nome[i]) + ": " + tempo[i]);
		}

	}

	public static void Total(double tempo[], double totais) {

		for (int i = 0; i < tempo.length; i++) {

			totais += tempo[i];

		}
		System.out.println("O valor final � de: " + totais);
	}

}
