import java.util.Scanner;

public class Eatruturaencadeada {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double valorp,valord, resultado;
		Scanner teclado = new Scanner(System.in);
		
		System.out.print("insira o valor do produto: $");
		valorp = teclado.nextDouble();
		
		System.out.print("insira o valor de desconto: %");
		valord = teclado.nextDouble();
		
	valord = valord / 100;
	resultado = valord * valorp;
	
	

	System.out.println("o valor do produto �: " + resultado);
		
		
		
		
		
		
		
	}

}
