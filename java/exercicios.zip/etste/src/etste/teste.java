package etste;

import java.util.Scanner;

public class teste {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		int[] equipes;
		int totalEquipes;
		int batalhas;
		int qtdbatalhas;
		
		do {
			System.out.println("Informe o total de equipes entre 11 a 99 -->");
			totalEquipes = teclado.nextInt();
		} while (totalEquipes < 11 || totalEquipes > 99);
		
		
		
		String[][] tPlacar = new String[totalEquipes][3];

		
		for (int i = 0; i < totalEquipes; i++) {
				
			teclado.nextLine();
			System.out.println("Informe o n�mero de combate realizado da equipe" + "#" + 1);
			qtdbatalhas = teclado.nextInt();
			
			
			
			for (int j = 0; j < qtdbatalhas; j++) {
				
				System.out.println("Informe(V) para vitoria, (E) empate e (D) Derrota");
				tPlacar[i][j] = teclado.next();
				
				
			}

			
			
		}

	}
}
