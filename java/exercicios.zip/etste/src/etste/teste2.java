package etste;

import java.util.Iterator;
import java.util.Scanner;

public class teste2 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		int qtdEquipes, qtdbatalhas;
		double soma;
		
		// entrada da quantidade de competidores e de lan�amentos
		System.out.print("Quantidade de equipes --> ");
		qtdEquipes = teclado.nextInt();
		System.out.print("Quantidade de batalhas --> ");
		qtdbatalhas = teclado.nextInt();
		
		// declara��o das vari�veis
		int[] batalhas = new int[qtdEquipes];
		double[][] lutas = new double[qtdEquipes][qtdbatalhas];
		
		// entrada dos dados dos competidores e dos lan�amentos
		for(int i = 0; i < qtdEquipes; i++) {
			teclado.nextLine();
			System.out.println("Competidor --> " + (i+1));
			System.out.print("batalhas: ");
			batalhas[i] = teclado.nextInt();
			soma = 0;
			for(int j = 0; j < qtdbatalhas; j++) {
				System.out.print("Lan�amento " + (j+1) + " ");
				lutas[i][j] = teclado.nextDouble();
				soma += lutas[i][j];
			}
			lutas[i][qtdbatalhas] = soma;
			System.out.println();
		}
		
		// impress�o dos competidores e o total de pontos
		System.out.println("Listagem de competidores");
		for(int i = 0; i < qtdEquipes; i++) {
			System.out.println(batalhas[i] + " ---> " + lutas[i][qtdbatalhas]);
		}

	}

}
