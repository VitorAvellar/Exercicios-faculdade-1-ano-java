import java.util.Scanner;

public class teste3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int TotalEquipes; 
		System.out.print("Diga o n�mero de equipes participante por favor: ");
		TotalEquipes = teclado.nextInt();

		 
		
		int [] Placar = new int[TotalEquipes];
		
		int [] Times = new int[TotalEquipes];
		
		
		int [] deisignrobo = new int[TotalEquipes];
		
		int [] posicoes = new int[TotalEquipes]; 
		
		int quantdLutas,derrota, vitoria, empate; 

		

		for (int i = 0; i < TotalEquipes; i++) {
			
			System.out.println("Cooque o numero que ira representar a equipe: " + (i + 1));
			Times[i] = teclado.nextInt();
			if (Times[i] < 11 || Times[i] > 99) {
				
				System.out.println("ERRO - Coloque o numero entre 11 e 99");
				System.exit(0);
			}
		}
		
		System.out.print("coloque a quantidade de lutas por equipe");
		quantdLutas = teclado.nextInt();

		for (int i = 0; i < TotalEquipes; i++) {
			
			System.out.println("Coloque o numero de derrota da equipe");
			derrota = teclado.nextInt();
			
			System.out.println("Coloque o numero de vitoria da equipe " + (i + 1));
			vitoria = teclado.nextInt();
			
			System.out.println("Coloque o numero de empate da equipe");
			empate = teclado.nextInt();

			if (quantdLutas != vitoria + empate + derrota) {
				
				System.out.println("ERRO");
				System.exit(0);
			}

			Placar[i] = (vitoria * 5) + (empate * 3) + (derrota * 0);
			System.out.println("O placar do time  " + Times[i] + " � " + Placar[i]);
			System.out.print("Nota de disign do robo: ");
			deisignrobo[i] = teclado.nextInt();
			
			
		}
		
		
		for (int i = 0; i < TotalEquipes; i++) {
			boolean finalizado = true;
			for (int j = 0; j < Placar.length - i - j; j++) {
				
				if (Placar[j] < Placar[j + 1]) {
					int Placaraux = Placar[j];
					Placar[j] = Placar[j + 1];
					Placar[j + 1] =Placaraux;
					int timeaux = Times[j];
					Times[j] = Times[j + 1];
					Times[j + 1] = timeaux;
					finalizado = false;
				}
			}
			if (finalizado) {
				break;
			}
		}
		for (int i = 0; i < TotalEquipes; i++) {
			boolean finalizado = true;
			for (int j = 0; j < Placar.length - i - j; j++) {
				if (Placar[j] == Placar[j + 1] && deisignrobo[j] < deisignrobo[j + 1]) {
					int Placaraux = Placar[j];
					Placar[j] = Placar[j + 1];
					Placar[j + 1] = Placaraux;
					int timeaux = Times[j];
					Times[j] = Times[j + 1];
					Times[j + 1] = timeaux;
					finalizado = false;
				}
			}
			if (finalizado) {
				break;
			}
		}
		for (int i = 0; i < TotalEquipes; i++) {
			posicoes[i] = Times[i];
		}
		for (int i = 0; i < TotalEquipes; i++) {
			System.out.println("Rank " + (i + 1) + ": " + posicoes[i] + " Score: " + Placar[i]);
		}
		teclado.close();

	}

}
