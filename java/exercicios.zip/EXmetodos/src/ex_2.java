import java.util.Scanner;

public class ex_2 {

	public static void main(String[] args) {

		
		
		Scanner teclado = new Scanner(System.in);
		int lado1,lado2,lado3,lados = 0;
		
		System.out.print("Digite um valor para o lado A: ");
		lado1 = teclado.nextInt();
		
		System.out.print("Digite um valor para o lado B: ");
		lado2 = teclado.nextInt();
		
		System.out.print("Digite um valor para o lado C: ");
		lado3 = teclado.nextInt();
		
		
		
		triangulos(lado1, lado2, lado3, lados);
		
		
		
	}
	
	public static void triangulos (int  ladoA, int ladoB, int ladoC, int lados) {
		 
		lados = 0;
		
		if(ladoA + ladoB < ladoC && ladoB + ladoC < ladoA && ladoC + ladoA < ladoB ) {
			
			System.out.println("Equilatero");
		}
		
		else if ( ladoA + ladoB < ladoC || ladoB + ladoC < ladoA || ladoC + ladoA < ladoB )  {
			
			System.out.println("isoceles");
		}
		else {
			System.out.println("escaleno");
		}
		
	
		
		
		
	}
	
	

}
