import java.util.Scanner;

public class ex_1 {

	public static void main(String[] args) {

		Scanner teclado =  new Scanner(System.in);
		
		int numero;
		System.out.print("Digite um numero para ser testatado: ");
		numero = teclado.nextInt();
		
		testePAReIMPAR(numero);
		
		
		
	}

	
	
	public static void testePAReIMPAR(int numero) {
		
		numero = numero % 2;
		if (numero == 0) {
			System.out.println("par");
		}
		else {
			System.out.println("impar");
		}
		
		
		
	}
	
	
	
}
