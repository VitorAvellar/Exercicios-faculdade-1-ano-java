import java.util.Scanner;

public class ex_5 {

	public static void main(String[] args) {

		
		Scanner teclado = new Scanner(System.in);
		 double A,B,C, delta = 0,x1, x2;
		
		System.out.print("digite o valor de A: ");
		A = teclado.nextDouble();
		
		System.out.print("digite o valor de B: ");
		B = teclado.nextDouble();
		
		System.out.print("digite o valor de C: ");
		C = teclado.nextDouble();
		
		
		deltaC(A, B, C, delta);
		
		x1 = raizMenor(A, B, delta);
		x2 = raizMaior(A, B, delta);
		
		System.out.println(x1);
		System.out.println(x2);
		
		
		
		
		
	}

	
	public static  double deltaC ( double a,  double b,  double c,  double delta ) {
		
		delta = (b*b - 4 * a * c);
		
		return(delta);
		
	}
	
	
	public static double raizMenor ( double a ,  double b,  double  delta) {
		 double x;
		
		x = (-b - Math.sqrt(delta))/(2 * a);
		
		
		
		return x;
		
		
	}
	
public static double raizMaior ( double a ,  double b,  double  delta) {
		
		double x;
		x = (-b + Math.sqrt(delta))/(2 * a);
		
		
		
		return x;
		
		
	}
	
	
	
	
	
	
	
}
