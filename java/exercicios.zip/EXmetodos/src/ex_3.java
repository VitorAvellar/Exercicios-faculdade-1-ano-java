import java.util.Scanner;

public class ex_3 {

	public static void main(String[] args) {

		
		Scanner teclado = new Scanner(System.in);
		int valor1,valor2,valor3, maior = 0;
		
		System.out.print("Digite o valor 1: ");
		valor1 = teclado.nextInt();
		
		System.out.print("Digite o valor 2: ");
		valor2 = teclado.nextInt();
		
		System.out.print("Digite o valor 3: ");
		valor3 = teclado.nextInt();
		
		
		System.out.print("O maior valor �: "+  maiores(valor1, valor2, valor3, maior));
		
		
	}
	
	
	public static int maiores(int V1,int V2 ,int V3,int maior) {
		
		
		
		
		if(V1 > V2 && V1 > V3) {
			 maior  = V1;
		
		}
		
		else if (V2 > V1 && V2 > V3) {
			 maior  = V2;
		}
		

		else if (V3 > V1 && V3 > V2) {
			 maior  = V3;
		}
	
		return(maior);
		
	}
	

}
