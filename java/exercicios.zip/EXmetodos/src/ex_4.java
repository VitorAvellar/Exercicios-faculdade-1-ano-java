import java.util.Random;

/* Programa em java que realize as seguintes funcionalidades:
 * 1. preencher um array com n�meros aleat�rios (preencher em um m�todo)
 * 2. imprimir os dados do array no v�deo (imprimir em um m�todo)
 * 3. m�todo que recebe como par�metro o array e retorne o maior e o menor
 * valor armazenado
 */
public class ex_4 {

	public static void main(String[] args) {

		int x[] = new int[5];
		int[] aux;

		NumRan(x);
		impress�o(x);
		aux = MAIOReMENOR(x);

		
		System.out.print("MAIOR: " + aux[0]);
		System.out.println();
		System.out.print("menor: " + aux[1]);
	}

	public static void NumRan(int[] x) {
		Random gerador = new Random();

		for (int i = 0; i < x.length; i++) {
			
			x[i] = gerador.nextInt(50);
			
		}

	}

	public static void impress�o(int[] x) {

		for (int i = 0; i < x.length; i++) {

			System.out.println(x[i] + " ");
		}
		System.out.println();
	}

	public static int[] MAIOReMENOR (int[] x ) {
		int aux [] = new int [2];
		aux[0] = x[0];
		aux[1] = x[0];
		
		
		for (int i = 0; i < x.length; i++) {
			
			if ( x[i] > aux[0]) {
				
				aux[0] = x[i];
			}
			
			if( x[i] < aux[1]) {
				aux[1] = x[i];
			}
		}
		
	return aux;
		
	}

}
