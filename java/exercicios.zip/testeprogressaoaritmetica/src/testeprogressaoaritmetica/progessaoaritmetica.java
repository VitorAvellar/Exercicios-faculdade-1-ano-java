package testeprogressaoaritmetica;

public class progessaoaritmetica {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//double a = 6, b = 10, c = 2, x;
		
	//	x=(-b+Math.sqrt(b*b -4*a*c))/2*a;
		
		//System.out.println(x);
		
			
		
		
		
		
	
		
	}

}
