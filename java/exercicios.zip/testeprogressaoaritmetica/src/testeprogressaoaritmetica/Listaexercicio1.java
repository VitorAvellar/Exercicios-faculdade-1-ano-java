package testeprogressaoaritmetica;

import java.util.Scanner;

public class Listaexercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n1, n2, resultado;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("insira o prieiro numero: ");
		n1 = teclado.nextInt();
		
		System.out.println("insira o segundo numero: ");
		n2 = teclado.nextInt();
		
		resultado = n1 + n2;
	
				System.out.println("o resultado �: " + resultado);

				
				
				
				
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
