import java.util.Random;

public class ex_10 {

	public static void main(String[] args) {

		
	Random gerador = new Random();
	int a;
	int b;
	int c;
	
	a = gerador.nextInt(50);
	b = gerador.nextInt(50);
	c = gerador.nextInt(50);
	
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
	
		
	System.out.println("O maior �: " + maiores(a, b, c));
	}

	public static int maiores(int a , int b, int c) {
		int maior = 0;
		
		if(a > maior) {
			maior = a;
			
			if(b > maior) {
				maior = b;
			}
			
			if(c > maior) {
				maior = c;
			}
		}
		return maior;
		
		
		
		
	}
	
	
	
}
