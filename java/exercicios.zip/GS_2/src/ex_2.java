import java.util.Scanner;

public class ex_2 {

	public static void main(String[] args) {

		
		
		Scanner teclado = new Scanner(System.in);
		int [] x = new int [5];
		int par = 0;
		int impar = 0;
		
		for (int i = 0; i < x.length; i++) {
			
			System.out.print("numero:  ");
			x[i] = teclado.nextInt();
			
			
			if (x[i] % 2 == 0) {
				par = par + 1;
				
			}
			else {
				impar = impar + 1;
			}
			
			
		}
		System.out.println("par: " + par);
		System.out.println("impar: " + impar);

		
		
		
		
		
	}

}
