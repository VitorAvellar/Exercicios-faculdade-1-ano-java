import java.util.Random;

public class ex_4 {

	public static void main(String[] args) {

		
		Random gerador = new Random();
		int []x = new int [10];
		
		for (int i = 0; i < x.length; i++) {
			
			x[i] = gerador.nextInt(10);
			
			if(x[i] != x[i]) {
				
				System.out.println(x[i]);
			
				
			}
			
			
			
		}
		
		
		
		
		
		
	}

}
