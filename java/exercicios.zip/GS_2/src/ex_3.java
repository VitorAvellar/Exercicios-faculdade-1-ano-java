import java.util.Scanner;

public class ex_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado = new Scanner(System.in);
		
		double[] dias = new double [7]; 
 		double media = 0;
 		
		for (int i = 0; i < dias.length; i++) {
			System.out.print("temperatura maxima do dia: ");
			dias[i] = teclado.nextDouble();
			
			media = media +  dias[i];
			
			
			
		}
		
			media = media / 7;
			System.out.println("Média da semana = " + media);
		
		for (int i = 0; i < dias.length; i++) {
			
			if(dias[i] >= media) {
				System.out.println("dia da semana: " + dias[i]);
			}
			
			
		}
		
		
		
	}

}
