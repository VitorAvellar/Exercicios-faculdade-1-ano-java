import java.util.Iterator;
import java.util.Scanner;

public class ex_1 {

	public static void main(String[] args) {


		Scanner teclado = new Scanner(System.in);
		int x [] = new int [5];
		
		int menor = 200;
		int maior = -200;
		
		
		
		for (int i = 0; i < x.length; i++) {
			
			System.out.print("Digite um numero: ");
			x[i] = teclado.nextInt();
			
			if (x[i] < menor) {
				menor = x[i];
			}
			
			if (x[i] > maior) {
				maior = x[i];
			}
		}
		
		System.out.println("O menor:" + menor);
		System.out.println("O maior:" + maior);
		
		
		
		
		
	}

}
