import java.util.Scanner;

public class EX_8 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		int QtdNome, QtdLanc;
		int soma;

		System.out.println("digite a qantidade de participantes: ");
		QtdNome = teclado.nextInt();

		System.out.println("digite a qantidade de lan�amentos ");
		QtdLanc = teclado.nextInt();

		String nomes[] = new String[QtdNome];
		int compet[][] = new int[QtdNome][QtdLanc+1];

		System.out.println();
		for (int i = 0; i < QtdNome; i++) {

			System.out.print("Digite o nome do paricipante " + (i + 1) + ": ");
			nomes[i] = teclado.next();

			soma = 0;
			for (int j = 0; j < QtdLanc; j++) {

				System.out.print("Digite a distancia do lan�amento" + (j + 1) + ": ");
				compet[i][j] = teclado.nextInt();

				soma = soma + compet[i][j];

			}
			
			compet[i][QtdLanc] = soma;

			System.out.println();

		}

		System.out.println();
		for (int i = 0; i < compet.length; i++) {
			System.out.println("total do(a) " + nomes[i] + " � " + compet[i][QtdLanc]);

		}

	}

}
