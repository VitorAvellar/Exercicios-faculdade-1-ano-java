import java.util.Scanner;

public class ex_7 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		int qtdAlunos, qtdProvas;
		double media;

		System.out.println("quantidade de alunos: ");
		qtdAlunos = teclado.nextInt();

		System.out.println("quantidade de provas: ");
		qtdProvas = teclado.nextInt();

		String alunos[] = new String[qtdAlunos];
		double notas[][] = new double[qtdAlunos][qtdProvas];

		System.out.println();

		for (int i = 0; i < qtdAlunos; i++) {
			System.out.print("Nome do aluno " + (i + 1) + ":  ");
			alunos[i] = teclado.next();

			media = 0;

			for (int j = 0; j < qtdProvas; j++) {

				System.out.print("Digite a nota " + (j + 1) + " do(a) " + alunos[i] + " ");
				notas[i][j] = teclado.nextDouble();

				media = media + notas[i][j];

			

				for (int j2 = 0; j2 < notas.length; j2++) {
					
					media = media / 3;
					
				}

			}

			System.out.println();

		}

	}

}
