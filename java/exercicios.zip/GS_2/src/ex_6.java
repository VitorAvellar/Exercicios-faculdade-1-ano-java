import java.util.Random;

public class ex_6 {

	public static void main(String[] args) {

		Random gerador = new Random();
		int d[][] = new int[3][3];
		int maior = 0;

		for (int i = 0; i < d.length; i++) {
			for (int j = 0; j < d.length; j++) {

				d[i][j] = gerador.nextInt(1000);
				System.out.print(d[i][j] + "\t");

				if (d[i][j] > maior) {
					maior = d[i][j];
				}
				
			}
			System.out.println();
		}

		System.out.println("O maior: " + maior);
		
		System.out.println();
		
		for (int i = 0; i < d.length; i++) {
			for (int j = 0; j < d.length; j++) {
				
				if (d[i][j] == maior) {
					System.out.println("na linha " + i  );
					System.out.println("na coluna " + j  );

					
				}
			}
		}

	}

}
