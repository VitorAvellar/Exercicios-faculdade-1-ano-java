import java.util.Random;
import java.util.Scanner;

public class ex_5 {

	public static void main(String[] args) {


		Random gerador = new Random();
		int x [][] = new int [4][4];
		
		for (int i = 0; i < x.length; i++) {
			for (int j = 0; j < x.length; j++) {
				x[i][j] = gerador.nextInt(50);
				
				System.out.print(x[i][j] + "\t");
				
				
				
			}
			System.out.println();
		}
		
		
		
	}

}
