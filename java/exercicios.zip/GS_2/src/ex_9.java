import java.util.Random;

public class ex_9 {

	public static void main(String[] args) {

		Random gerador = new Random();

		int x[][] = new int[2][3];
		int y[][] = new int[3][2];

		for (int i = 0; i < x.length; i++) {
			for (int j = 0; j < y.length; j++) {
				x[i][j] = gerador.nextInt(50);

				y[j][i] = x[i][j];
				System.out.print(x[i][j] + "\t");

			}
			System.out.println();
		}

		System.out.println();
		for (int i = 0; i < y.length; i++) {
			for (int j = 0; j < y[i].length; j++) {

				System.out.print(y[i][j] + "\t");
			}
			System.out.println();
		}

	}

}
