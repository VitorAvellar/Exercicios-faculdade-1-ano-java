import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int x, y, z;
		
		System.out.print("Valor 1 --> ");
		x = teclado.nextInt();
		System.out.print("Valor 2 --> ");
		y = teclado.nextInt();
		System.out.print("Valor 3 --> ");
		z = teclado.nextInt();

		System.out.println("maior valor = " + acharMaior(x, y, z));
		
	}

	public static int acharMaior(int x, int y, int z) {
		int maior = 0;
		if(x > y && x > z) {
			maior = x;
		} else if(y > z) {
			maior = y;
		} else {
			maior = z;
		}
		return maior;
	}
	
}
