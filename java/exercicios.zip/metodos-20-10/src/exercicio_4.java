import java.util.Scanner;

public class exercicio_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		double a, b, c;
		double delta, x1, x2;

		System.out.print("Diga o valor de A: ");
		a = teclado.nextDouble();
		
		
		
		if (a == 0) {
			System.out.println("Valor errado coloque vaor diferente de zero");

		}

		else {
			
			
			System.out.print("Diga o valor de B: ");
			b = teclado.nextDouble();

			System.out.print("Diga o valor de C: ");
			c = teclado.nextDouble();
			
			delta =  ResultadoDelta(a, b, c);
			if (delta < 0 ) {
				System.out.println("Equa��o n�o tem raiz");
			
			}
			else {
				x1 = calcularRaizP(a, b, delta);
				x2 = calcularRaizN(a, b, delta);		
				
				System.out.println("X1--> " + x1);
				System.out.println("X2--> " + x2);
				
			}
			
		}
		
		
	}

	public static double ResultadoDelta(double a, double b, double c) {

		return  (b * b - 4 * a * c);

		

	}

	public static double calcularRaizP(double a, double b, double delta) {

		double x;

		x = (-b + Math.sqrt(delta) / (2 * a));

		return x;

	}

	public static double calcularRaizN(double a, double b, double delta) {

		double x;

		x = (-b - Math.sqrt(delta) / (2 * a));

		return x;

	}

}
