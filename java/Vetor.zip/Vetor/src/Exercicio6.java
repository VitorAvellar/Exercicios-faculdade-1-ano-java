import java.util.Scanner;

public class Exercicio6 {
	public static void main(String[] args) {
		
		// declaração de variáveis
		Scanner teclado = new Scanner(System.in);
		int qtdSala, qtdAluno;
		int[] nota; // apenas a declaração
		double media;
		double porcentagem;
		
		System.out.print("Quantidade de salas de aula --> ");
		qtdSala = teclado.nextInt();
		
		for(int sala = 1; sala <= qtdSala; sala++) {
			System.out.println("Sala #" + sala);
			System.out.print("Quantidade de alunos --> ");
			qtdAluno = teclado.nextInt();
			nota = new int[qtdAluno];
			media = 0;
			for(int aluno = 0; aluno < qtdAluno; aluno++) {
				System.out.print("Nota do aluno #" + (aluno+1) + " ");
				nota[aluno] = teclado.nextInt();
				media = media + nota[aluno]; // media += nota[aluno];
			}
			media = media / qtdAluno; // media /= qtdAluno;
			System.out.println("Media da sala de aula " + String.format("%.3f", media));
			porcentagem = 0;
			for(int i = 0; i < nota.length; i++) {
				if(nota[i] > media) {
					porcentagem++;
				}
			}
			porcentagem = porcentagem / qtdAluno * 100;
			System.out.println("Porcentagem de alunos acima da media " + String.format("%.3f%%", porcentagem));
			
			System.out.println();
		}
	}
}
