import java.util.Scanner;

public class Exercicio2 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int[] x = new int[5];
		int par = 0;
		
		for(int i = 0; i < x.length; i++) {
			System.out.print("valor: ");
			x[i] = teclado.nextInt();
			
			if(x[i] % 2 == 0) {
				par++;
			}
		}
		
		System.out.println("total de pares = " + par);
		System.out.println("total de ímpares = " + (x.length - par));

	}
}
