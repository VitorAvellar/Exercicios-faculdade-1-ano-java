import java.util.Scanner;

public class Exercicio8 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int qtdFuncionario;
		
		System.out.print("Quantidade de funcionários --> ");
		qtdFuncionario = teclado.nextInt();
		
		double[] salario = new double[qtdFuncionario];
		String[] nome = new String[qtdFuncionario];
		double total = 0;
		
		for(int i = 0; i < qtdFuncionario; i++) {
			teclado.nextLine();
			System.out.print("Nome --> ");
			nome[i] = teclado.nextLine();
			System.out.print("Salário --> R$ ");
			salario[i] = teclado.nextDouble();
			
			total = total + salario[i]; // total += salario[i];			
		}
		
		System.out.println("Total da folha de pagamento R$ " + String.format("%.2f", total));
		System.out.println("Média salarial R$ " + String.format("%.2f", total/qtdFuncionario));
		
		// qual é o funcionário que tem o maior salário?
		
	}
}
