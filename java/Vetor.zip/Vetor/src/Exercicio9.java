import java.util.Random;

public class Exercicio9 {
	public static void main(String[] args) {
		
		Random gerador = new Random();
		int[] x = new int[gerador.nextInt(2, 15)];
		int aux;
		
		//preencher e imprimir os dados do vetor
		System.out.println("Antes da ordenacao:");
		for(int i = 0; i < x.length; i++) {
			x[i] = gerador.nextInt(15, 156);
			System.out.print(x[i] + " ");
		}
		
		// ordenação dos dados em ordem crescente
		for(int j = 1; j <= x.length; j++) {
			for(int i = 0; i < x.length - 1; i++) {
				if(x[i] > x[i+1]) {
					aux = x[i+1];
					x[i+1] = x[i];
					x[i] = aux;
				}
			}
		}
		
		// imprime os dados após a ordenação
		System.out.println("\n\nApos a ordenacao:");
		for(int i = 0; i < x.length; i++) {			
			System.out.print(x[i] + " ");
		}

	}
}
