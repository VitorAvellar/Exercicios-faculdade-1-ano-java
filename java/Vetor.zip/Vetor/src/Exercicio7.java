import java.util.Random;

public class Exercicio7 {
	public static void main(String[] args) {
		
		Random gerador = new Random();
		int[] x = new int[gerador.nextInt(1, 15)];
		boolean achou;
		
		for(int i = 0; i < x.length; ) {
			x[i] = gerador.nextInt(x.length);
			achou = false;
			for(int j = 0; j < i; j++) {
				if(x[i] == x[j]) {
					achou = true;
				}
			}
			
			if(achou == false) {
				System.out.print(x[i] + " ");
				i++;
			}
		}

	}
}
