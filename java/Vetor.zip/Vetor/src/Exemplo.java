import java.util.Random;

public class Exemplo {
	public static void main(String[] args) {
		
		Random gerador = new Random();
		
		int x = gerador.nextInt() % 10;
		int y = gerador.nextInt(1500, 8793);
		double z = gerador.nextDouble() * 100;
		
		System.out.println(z);

	}
}
