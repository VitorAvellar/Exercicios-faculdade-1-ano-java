import java.util.Scanner;

public class Exercicio2 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		String nome, genero;
		double altura, peso;
		
		System.out.print("Nome do paciente: ");
		nome = teclado.nextLine();
		System.out.print("G�nero (masculino ou feminino): ");
		genero = teclado.next();
		System.out.print("Altura em metros: ");
		altura = teclado.nextDouble();
		
		genero = genero.toLowerCase();
		
		if(!genero.equals("feminino") && !genero.equals("masculino")) {
			System.out.println("G�nero inv�lido para essa aplica��o");
		} else {
			if(genero.equals("feminino")) {
				peso = 62.1 * altura - 44.7;
			} else {
				peso = 72.7 * altura - 58;
			}
			System.out.println(nome + ", seu peso ideal �: " + peso);
		}

	}
}
