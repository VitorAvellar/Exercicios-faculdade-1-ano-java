import java.util.Scanner;

/* Exerc�cio extra:
Escreva um programa que leia o nome e as duas notas de n alunos. Para cada aluno o programa deve imprimir a m�dia e 
a situa��o (aprovado ou reprovado). Ao final da execu��o dever� ser impresso o total de alunos que foram aprovados e o 
total de alunos que foram reprovados.
*/

public class Extra1 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int quantidade;
		String nome;
		double nota1, nota2, media;
		int contador = 1;
		int aprovado = 0;
		double porcentagem;
		
		System.out.print("Quantidade de alunos --> ");
		quantidade = teclado.nextInt();
		
		while(contador <= quantidade) {
			teclado.nextLine();
			System.out.println("Aluno " + contador);
			System.out.print("Nome: ");
			nome = teclado.nextLine();
			System.out.print("Nota 1: ");
			nota1 = teclado.nextDouble();
			System.out.print("Nota 2: ");
			nota2 = teclado.nextDouble();
			media = (nota1 + nota2) / 2;
			System.out.println("M�dia = " + media);
			if(media >= 6) {
				System.out.println("Aprovado");
				aprovado++;
			} else {
				System.out.println("Reprovado");
			}
			contador = contador + 1;
			System.out.println();
		}

		porcentagem = (double)aprovado / quantidade * 100;
		System.out.println("Porcentagem de aprovados: " + porcentagem);
		System.out.println("Porcentagem de reprovados: " + (100 - porcentagem));
		
	}
}
