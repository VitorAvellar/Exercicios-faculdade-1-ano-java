import java.util.Scanner;

public class Exercicio3 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int valor, cont = 0, resultado;
		
		System.out.print("valor --> ");
		valor = teclado.nextInt();
		
		while(cont <= 10) {
			resultado = valor * cont;
			System.out.println(valor + " * " + cont + " = " + resultado);
			cont++; // cont = cont + 1;
		}
		

	}
}
