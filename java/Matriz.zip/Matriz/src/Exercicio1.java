import java.util.Random;

public class Exercicio1 {
	public static void main(String[] args) {
		
		Random gerador = new Random();
		int[][] x = new int[3][3];
		int dp = 0, ds = 0;
		
		for(int i = 0; i < x.length; i++) {
			for(int j = 0; j < x.length; j++) {
				x[i][j] = gerador.nextInt(10);
				System.out.print(x[i][j] + "\t");
				
				if(i == j) {
					dp += x[i][j];
				}
				
				if(i + j == x.length - 1) {
					ds += x[i][j];
				}
				
			}
			System.out.println();
		}
		
		System.out.println("soma da diagonal principal = " + dp);
		System.out.println("soma da diagonal secundaria = " + ds);
	}
}
