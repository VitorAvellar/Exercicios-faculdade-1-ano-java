import java.util.Random;

public class Exercicio2 {
	public static void main(String[] args) {
		
		Random gerador = new Random();
		int[][] x = new int[4][4];
		int maior = 0;
		
		for(int i = 0; i < x.length; i++) {
			for(int j = 0; j < x[i].length; j++) {
				x[i][j] = gerador.nextInt(20);
				System.out.print(x[i][j] + "\t");
				if(x[i][j] > maior) {
					maior = x[i][j];
				}
			}
			System.out.println();
		}
		
		System.out.println("maior valor = " + maior);
		
		for(int i = 0; i < x.length; i++) {
			for(int j = 0; j < x[i].length; j++) {
				if(x[i][j] == maior) {
					System.out.println("x[" + i + "][" + j + "]");
				}
			}
		}
	}
}
