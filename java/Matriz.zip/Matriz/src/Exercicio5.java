import java.util.Random;
import java.util.Scanner;

public class Exercicio5 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		Random gerador = new Random();
		
		int totalLinha, totalColuna;
		
		System.out.print("Total de linha --> ");
		totalLinha = teclado.nextInt();
		System.out.print("Total de coluna --> ");
		totalColuna = teclado.nextInt();
		
		int[][] a = new int[totalLinha][totalColuna];
		int[][] b = new int[totalColuna][totalLinha];

		for(int i = 0; i < a.length; i++) {
			for(int j = 0; j < a[i].length; j++) {
				a[i][j] = gerador.nextInt(25);
				b[j][i] = a[i][j];
				System.out.print(a[i][j] + "\t");
			}
			System.out.println();
		}
		
		System.out.println();
		for(int i = 0; i < b.length; i++) {
			for(int j = 0; j < b[i].length; j++) {
				System.out.print(b[i][j] + "\t");
			}
			System.out.println();
		}
	}
}
