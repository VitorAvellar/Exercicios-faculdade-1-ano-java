import java.util.Random;
import java.util.Scanner;

public class Exercicio7 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		Random gerador = new Random();
		int totalVendedor;
		
		System.out.print("Total de vendedores --> ");
		totalVendedor = teclado.nextInt();
		
		String[] mes = {"Jan", "Fev", "Mar", "Abr", "Mai", "Jun"};
		String[] vendedor = new String[totalVendedor];
		double[][] venda = new double[totalVendedor][mes.length + 1];
		double totalVenda;
		double maiorVenda, menorVenda;
		int linhaMaiorVenda, linhaMenorVenda;
		
		// nome do vendedor e a geração das vendas
		teclado.nextLine();
		for(int i = 0; i < totalVendedor; i++) {
			System.out.print("Nome do vendedor #" + (i+1) + " ");
			vendedor[i] = teclado.nextLine();
			totalVenda = 0;
			for(int j = 0; j < mes.length; j++) {
				venda[i][j] = gerador.nextInt(5);
				totalVenda += venda[i][j];
			}
			venda[i][mes.length] = totalVenda;
		}
		
		// impressão da tabela de vendas
		System.out.println();
		System.out.println("Tabela de vendas");
		for(int i = 0; i < totalVendedor; i++) {
			for (int j = 0; j < mes.length; j++) {
				System.out.print(String.format("%.2f\t", venda[i][j]));
			}
			System.out.println();
		}
		
		// impressão dos vendedores e seus respectivos totais de vendas
		System.out.println();
		System.out.println("Total de vendas por vendedor");
		for(int i = 0; i < totalVendedor; i++) {
			System.out.println(vendedor[i] + " --> " + String.format("%.2f", venda[i][mes.length]));
		}
		
		// impressão do total de vendas por mês
		System.out.println();
		System.out.println("Total de vendas por mês");
		for(int j = 0; j < mes.length; j++) {
			totalVenda = 0;
			for(int i = 0; i < totalVendedor; i++) {
				totalVenda += venda[i][j];
			}
			System.out.println(mes[j] + " --> " + String.format("%.2f", totalVenda));
			
		}
		
		// impressão do nome do vendedor que teve a maior venda
		System.out.println();
		System.out.println("Vendedor com a maior venda");
		maiorVenda = Double.MIN_VALUE;
		linhaMaiorVenda = 0;
		for(int i = 0; i < totalVendedor; i++) {
			if(venda[i][mes.length] > maiorVenda) {
				maiorVenda = venda[i][mes.length];
				linhaMaiorVenda = i;
			}
		}
		System.out.println(vendedor[linhaMaiorVenda]);
		
		// impressão do nome do vendendor que teve a menor venda
		System.out.println();
		System.out.println("Vendedor com a menor venda");
		menorVenda = Double.MAX_VALUE;
		linhaMenorVenda = 0;
		for(int i = 0; i < totalVendedor; i++) {
			if(venda[i][mes.length] < menorVenda) {
				menorVenda = venda[i][mes.length];
				linhaMenorVenda = i;
			}
		}
		System.out.println(vendedor[linhaMenorVenda]);
		
	}
}
