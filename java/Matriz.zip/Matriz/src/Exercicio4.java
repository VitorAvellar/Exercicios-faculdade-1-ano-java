import java.util.Scanner;

public class Exercicio4 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int qtdCompetidor, qtdLancamento;
		double soma;
		
		// entrada da quantidade de competidores e de lançamentos
		System.out.print("Quantidade de competidores --> ");
		qtdCompetidor = teclado.nextInt();
		System.out.print("Quantidade de lançamentos --> ");
		qtdLancamento = teclado.nextInt();
		
		// declaração das variáveis
		String[] nome = new String[qtdCompetidor];
		double[][] lancamento = new double[qtdCompetidor][qtdLancamento + 1];
		
		// entrada dos dados dos competidores e dos lançamentos
		for(int i = 0; i < qtdCompetidor; i++) {
			teclado.nextLine();
			System.out.println("Competidor --> " + (i+1));
			System.out.print("Nome: ");
			nome[i] = teclado.nextLine();
			soma = 0;
			for(int j = 0; j < qtdLancamento; j++) {
				System.out.print("Lançamento " + (j+1) + " ");
				lancamento[i][j] = teclado.nextDouble();
				soma += lancamento[i][j];
			}
			lancamento[i][qtdLancamento] = soma;
			System.out.println();
		}
		
		// impressão dos competidores e o total de pontos
		System.out.println("Listagem de competidores");
		for(int i = 0; i < qtdCompetidor; i++) {
			System.out.println(nome[i] + " ---> " + lancamento[i][qtdLancamento]);
		}
	}
}
